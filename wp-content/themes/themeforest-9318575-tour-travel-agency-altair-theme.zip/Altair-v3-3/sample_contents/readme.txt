----------------------------------------------------------------------------
   Sample Contents
----------------------------------------------------------------------------

- All .xml is Wordpress XML import file of demo site. demo_contents.xml for pages, posts, tours etc. contents.

- import shop demo content use shop_contents.xml for shop and products which required Woocommerce plugin installed.

- theme_settings.json is theme admin panel predefined settings and you can import it using Theme Setting > Backup (content is NOT INCLUDED, only theme settings)